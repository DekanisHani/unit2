// const prodRow = document.querySelector("#main .row");
// const prods_URL = "https://striveschool-api.herokuapp.com/api/product/";

// const hideSpinner = () => {
//   let spinnerEl = document.querySelector(".spinner-border");
//   spinnerEl.classList.add("d-none");
// };

// const getProducts = async function () {
//   try {
//     let response = await fetch(prods_URL, {
//       method: "GET",
//       headers: {
//         "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDE0NzE3MGY4MWI0MjAwMTM5YjJhZjAiLCJpYXQiOjE2NzkwNjEzNjAsImV4cCI6MTY4MDI3MDk2MH0.84oeOP_oDU8eY6XQ3Tq1tBuvuZcSJq5Y1vHvtcXhfDA",
//       },
//     });
//     console.log(response);
//     if (response.ok) {
//       let products = await response.json();
//       hideSpinner();
//       products.forEach((el) => {
//         createCard(el.imageUrl, el.name, el._id, el.price);
//       });
//     } else {
//     }
//   } catch (error) {
//     console.log(error);
//   }
// };
// getProducts();

// let createCard = (prodImg, prodName, prodId, prodPrice) => {
//   let newCol = document.createElement("div");
//   newCol.setAttribute("class", "col-12 col-md-4 col-xl-3");
//   newCol.innerHTML = `<div class="card border-0" style="width: 70%; height: 500px"><img src="${prodImg}" class="card-img-top" alt="..."><div class="card-body"><div class="mb-2"><h5 class="card-title">${prodName}</h5><span class="badge bg-primary rounded-pill" style="font-size: 26px">${prodPrice}$</span></div><a href="./details.html?prodId=${prodId}" id="btnMore" class="btn btn-success me-2 border border-dark border-2">More</a><a href="./backoffice.html?prodId=${prodId}" id="btnModify" class="btn  me-2 border border-dark border-2">Modify</a></div></div>`;
//   prodRow.appendChild(newCol);
// };

//DEKANIS_______________________________________________________________________________________________________
const STRIVE_URL = "https://striveschool-api.herokuapp.com/api/product/";
const prodRow = document.querySelector("#main .row");

const caricamento = () => {
  let spinner = document.getElementsByClassName(".spinner-border");
  spinner.classList.add("d-none");
}

const getFromAPI = async function() {
  try {
    let response = fetch(STRIVE_URL, {
      headers: {
        "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDE0NzE3MGY4MWI0MjAwMTM5YjJhZjAiLCJpYXQiOjE2NzkyMzM5OTQsImV4cCI6MTY4MDQ0MzU5NH0.8P6CdDJDQJ6I5Jhs9OCMXXYBdQ9xYtg3LrZN003SBRM",
      },
    });
    console.log(response);
    if(response.ok) {
      let objs = await response.json();
      caricamento();
      console.log("el")
      objs.forEach((el) => {
        card(el.imageUrl, el.name, el._id, el.price)
      });
    }
    else{
      console.log("ciao")
    }
  }catch (error){
    console.log(error);
  }
};

getFromAPI();

let card = (prodImg, prodName, prodId, prodPrice) => {
  let newCol = document.createElement("div");
  newCol.setAttribute("class", "col-12 col-md-4 col-xl-3");
  newCol.innerHTML = `<div class="card border-0" style="width: 70%; height: 500px"><img src="${prodImg}" class="card-img-top" alt="..."><div class="card-body"><div class="mb-2"><h5 class="card-title">${prodName}</h5><span class="badge bg-primary rounded-pill" style="font-size: 26px">${prodPrice}$</span></div><a href="./details.html?prodId=${prodId}" id="btnMore" class="btn btn-success me-2 border border-dark border-2">More</a><a href="./backoffice.html?prodId=${prodId}" id="btnModify" class="btn  me-2 border border-dark border-2">Modify</a></div></div>`;
  prodRow.appendChild(newCol);
};

// const getFetch = () => {
//   fetch(STRIVE_URL, {
//     headers: {
//       "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDE0NzE3MGY4MWI0MjAwMTM5YjJhZjAiLCJpYXQiOjE2NzkwNjEzNjAsImV4cCI6MTY4MDI3MDk2MH0.84oeOP_oDU8eY6XQ3Tq1tBuvuZcSJq5Y1vHvtcXhfDA",
//     },
//   }).then(response => {
//     return response.json();
//   }).then (result => {
//     console.log(result);
//   })
// } 
// getFetch();


